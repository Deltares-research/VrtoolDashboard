from pathlib import Path

default_unit_costs_csv = Path(__file__).parent / "unit_costs.csv"
