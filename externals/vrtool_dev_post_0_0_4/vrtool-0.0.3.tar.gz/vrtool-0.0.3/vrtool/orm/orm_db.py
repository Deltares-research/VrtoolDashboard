from peewee import SqliteDatabase

vrtool_db = SqliteDatabase(None)
