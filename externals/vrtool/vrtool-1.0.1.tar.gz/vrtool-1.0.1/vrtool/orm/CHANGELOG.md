## 0.1.8

## Feat

- [VRTOOL-188] Added columns to `SectionData`: `sensitive_fraction_piping` and `sensitive_fraction_stability_inner`

## 0.1.7

## Feat

- [VRTOOL-544] Remove columns from `StandardMeasure`: `prob_of_solution_failure`, `failure_probability_with_solution`, `stability_screen_s_f_increase` (#341).


## 0.1.6

## Feat

- [VRTOOL-545] Added property `flood_damage` to `SectionData` (#343).


## 0.1.5

## Feat

- [VRTOOL-547] Renamed `CustomMeasureDetail` property `year` to `time` (#338).

## 0.1.4

### Feat

- [VRTOOL-546] Adding `n_revetment` and `n_overflow` to `DikeTrajectInfo` (#337).


## 0.1.3

### Feat

- [VRTOOL-542] Migration of tables to remove `year` key from `Measure` table (#335).



## 0.1.2

### Feat

- [VRTOOL-542] Migration of tables to include `on_delete="CASCADE"` for all foreign keys (#332).


## 0.1.1

### Feat

- [VRTOOL-539] Add versioning to the database (#326)