from vrtool.failure_mechanisms.general.generic_failure_mechanism_calculator import (
    GenericFailureMechanismCalculator,
)
from vrtool.failure_mechanisms.general.generic_failure_mechanism_input import (
    GenericFailureMechanismInput,
)
