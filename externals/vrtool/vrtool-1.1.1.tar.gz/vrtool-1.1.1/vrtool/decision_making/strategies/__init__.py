from vrtool.decision_making.strategies.greedy_strategy import GreedyStrategy
from vrtool.decision_making.strategies.target_reliability_strategy import (
    TargetReliabilityStrategy,
)
